Fura Powerline
==============

:Font creator: Erik Spiekermann, Ralph du Carrois (Carrois Type Design, Mozilla Foundation)
:Version: 3.206
:Source: https://github.com/mozilla/Fira
:License: SIL OPEN FONT LICENSE Version 1.1
:Patched by: `Tripurari Shankar <https://github.com/tripurari001>`_

Designed to integrate with the character of the Mozilla FirefoxOS, the Fira
typefaces also aim to cover the legibility needs for a large range of handsets
varying in screen quality and rendering.

Fura Powerline is derived from Fira Mono for Powerline users. The Powerlin Kim
Silkebækken. The patch work is being undertaken by Carl X. Su.  symbols is
being made by Pablo Olmos de Aguilera C.
